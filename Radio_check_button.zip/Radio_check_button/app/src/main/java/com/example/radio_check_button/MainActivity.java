package com.example.radio_check_button;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import static com.example.radio_check_button.R.drawable.ic_sentiment_very_satisfied_black_24dp;

public class MainActivity extends AppCompatActivity  {
   CheckBox angree,free,pubg,cricket,ludo;
   RadioGroup radio1;
   RadioButton radioButton;
   String s;
   Button sub,res,sub1;
   Toast Mytoast;
   LinearLayout layout;
   TextView game,minor;
    List<CheckBox> items = new ArrayList<CheckBox>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        layout=findViewById(R.id.layout_id);
        angree=(CheckBox)findViewById(R.id.check1);
        free=(CheckBox)findViewById(R.id.check2);
        pubg=(CheckBox)findViewById(R.id.check3);
        cricket=(CheckBox)findViewById(R.id.check4);
        ludo=(CheckBox)findViewById(R.id.check5);
        game=(TextView)findViewById(R.id.games);
        minor=(TextView)findViewById(R.id.minors);
        items.add(angree);
        items.add(free);
        items.add(pubg);
        items.add(cricket);
        items.add(ludo);
        radio1=(RadioGroup)findViewById(R.id.radiogroup);
        sub= (Button)findViewById(R.id.button);
        res=findViewById(R.id.reset);
        sub1=findViewById(R.id.button1);
        Mytoast = new Toast(this);
        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                layout.setBackgroundResource(R.drawable.back2_main);
                chekforBox();
            }
        });
        res.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                game.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_sentiment_dissatisfied_black_24dp,0,0,0);
                minor.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_sentiment_dissatisfied_black_24dp,0,0,0);
                layout.setBackgroundResource(R.drawable.main_backg);
                int c=0;
                for(CheckBox item : items){
                    if(item.isChecked())
                        c++;
                    item.setChecked(false);
                }
                int check=radio1.getCheckedRadioButtonId();
                if(check>0) {
                    radio1.clearCheck();
                    showToast(" CLEARED");

                }
                else if(c>0){
                    showToast(" CLEARED");
                    return;
                }
                else
                Message("NOTING TO CLEAR","");
            }
        });
        sub1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                layout.setBackgroundResource(R.drawable.back2_main);
                checkforRadio();
            }
        });
    }
    public void showToast(String s) {
        LayoutInflater inflater = getLayoutInflater();
        View v = inflater.inflate(R.layout.custom_toast,(ViewGroup)findViewById(R.id.custom_la));
        TextView textView = v.findViewById(R.id.mytext);
        textView.setText(s);
        Mytoast.setGravity(Gravity.CENTER_VERTICAL,0,-150);
        Mytoast.setView(v);
        Mytoast.setDuration(Toast.LENGTH_SHORT);
        Mytoast.show();
    }
    public void chekforBox() {
        StringBuffer buffer=new StringBuffer();
        int cnt = 0;
        for (CheckBox item : items){
            if(item.isChecked()){
               buffer.append(item.getText().toString());
               buffer.append("\n");
                cnt++;
               }
        }
        if(cnt>0) {
            game.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_sentiment_very_satisfied_black_24dp,0,0,0);

            Message("SELECTED GAMES", String.valueOf(buffer));
        }
        else {
            showToast("NO GAME SELECTED");
            game.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_sentiment_dissatisfied_black_24dp, 0, 0, 0);
        }

    }

    public void checkforRadio() {
        int c= radio1.getCheckedRadioButtonId();
        if(c>0)
        {
            radioButton = findViewById(c);
            s = radioButton.getText().toString();
            showToast(s+" SELECTED");
            minor.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_sentiment_very_satisfied_black_24dp,0,0,0);
        }
        else{
            showToast("NO MINOR SELECTED");
            minor.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_sentiment_dissatisfied_black_24dp,0,0,0);

        }

    }
    public void Message(String a,String b)
    {
        AlertDialog.Builder  builder= new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(a);
        builder.setMessage(b);
        builder.show();
    }

}
